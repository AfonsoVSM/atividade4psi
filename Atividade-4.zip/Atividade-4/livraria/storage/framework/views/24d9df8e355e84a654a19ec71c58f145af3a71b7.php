<ul>
<?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($genero->designacao); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($generos->render()); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/generos/index.blade.php ENDPATH**/ ?>