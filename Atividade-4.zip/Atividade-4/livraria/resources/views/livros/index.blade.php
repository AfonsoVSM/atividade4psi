<ul>
@foreach($livros as $livro)
<li>
	<a href="{{route('livros.show', ['id'=>$livro->id_livro])}}"></a>
	{{$livro->titulo}}</li>
@endforeach
</ul>
{{$livros->render()}}

